// header hamburger menu js code is here
function toggleMenu() {
    const navLinks = document.getElementById("navbar-list");
    if (navLinks.classList.contains("show")) {
        navLinks.classList.remove("show"); // Menü açıksa kapat
    } else {
        navLinks.classList.add("show"); // Menü kapalıysa aç
    }
}

// FAQ for whyhizzacademy 

document.addEventListener("DOMContentLoaded", function() {
    const faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(item => {
      const question = item.querySelector('.faq-question');

      question.addEventListener('click', () => {
        const answer = item.querySelector('.faq-answer');
        const isActive = answer.style.display === 'block';

        faqItems.forEach(item => {
          item.querySelector('.faq-answer').style.display = 'none';
        });

        if (!isActive) {
          answer.style.display = 'block';
        }
      });
    });
  });