function filtrele(kategori){
 const urunler = document.getElementsByClassName("urun");
 for(var i=0; i< urunler.length;i++){
    if(urunler[i].classList.contains(kategori)){
        urunler[i].style.display="block";
    }else{
        urunler[i].style.display="none";
    }
 }
}


// function filtrele(kategori){
//     var urunler = document.getElementsByClassName("urun");
//     for(var i=0; i< urunler.length;i++){
//       if(urunler[i].classList.contains(kategori)){
//         urunler[i].style.display="block";
        
//       }else{
//         urunler[i].style.display="none";
//       }
//     }
//    }